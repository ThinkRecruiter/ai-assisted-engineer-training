# Week 24 Final Build

    ## Objectives
    - See the plan in the main README.
- Follow the weekly objectives.

    ## Deliverables
    - Complete the listed deliverables.
- Commit at least once with a descriptive message.

    ## AI Prompt Templates
    Copy/paste and adapt these into your AI assistant. Provide your own context (what you want to build, fields, formats).

    > Provide me with starter code and a short explanation for this week's focus.

    ## Milestones Checklist
    - [ ] Ran the starter code
    - [ ] Completed the exercises
    - [ ] Committed to GitHub with a clear message
    - [ ] (If applicable) Deployed and tested